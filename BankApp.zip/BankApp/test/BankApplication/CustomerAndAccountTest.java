/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BankApplication;

import BA.CheckingAccount;
import Hibernate.Hibernate;
import Model.Account;
import Model.Customers;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author ub2232e
 */
public class CustomerAndAccountTest {

    public CustomerAndAccountTest() {
    }

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    // @Test
    // public void hello() {}
    @Test
    public void insertAndGetAccountAndCustomerTest() {
        int sortCode = 816012;
        int accountNumber = 56254125;
        String branch = "Bob";
        String IBAN = "Bob";

        String name = "Bob";
        String surname = "Bob";
        int passportID = 3;
        int phoneNumber = 2;
        String address = "Greenwich";
        String email = "bob@gre.ac.uk";
        double balance = 0.0;
        Hibernate db = new Hibernate();
        CheckingAccount cr = new CheckingAccount(balance);
        Account acc = new Account(sortCode, accountNumber, branch, IBAN, cr.getClass().getName(), 0.0);
        Customers newCustomer = new Customers(name, surname, address,
                email, passportID, phoneNumber, cr.getClass().getName(), acc);
        db.createCustomer(newCustomer);

        assertTrue(816012 == db.getAccount().getSortCode());
        assertTrue(56254125 == db.getAccount().getAccountNumber());
        assertTrue("Bob".equals(db.getAccount().getBranchName()));
        assertTrue("Bob".equals(db.getAccount().getIBAN()));
        assertTrue(0.0 == db.getAccount().getBalance());

        assertTrue(db.getCustomers().getPassportID() == 3);
        assertTrue(2 == db.getCustomers().getPhoneNumber());
        assertTrue("Bob".equals(db.getCustomers().getFirstname()));
        assertTrue("Bob".equals(db.getCustomers().getLastname()));
        assertTrue("Greenwich".equals(db.getCustomers().getAddress()));
        assertTrue("bob@gre.ac.uk".equals(db.getCustomers().getEmail()));

    }
    //Create Account Class exactly like Customer.java and put in here a test for get SortCode, same thing...
}
