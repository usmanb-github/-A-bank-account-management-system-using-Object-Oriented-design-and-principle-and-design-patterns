/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BankApplication;

import Hibernate.Hibernate;
import org.junit.After;
import org.junit.AfterClass;
import static org.junit.Assert.assertTrue;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

/**
 *
 * @author ub2232e
 */
public class WithdrawPaymentTest {

    public WithdrawPaymentTest() {
    }

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    // @Test
    // public void hello() {}
    @Test
    public void DepositPaymentTest() {
        int sortCode = 816012;
        int accountNumber = 56254125;
        Hibernate db = new Hibernate();
        double deposit = 10.0;
        double balance = (db.getBalance(sortCode, accountNumber).getBalance() - deposit);
        if (db.getAccount().getSortCode() == sortCode && db.getAccount().getAccountNumber() == accountNumber) {

            db.updateBalance(sortCode, accountNumber, balance);
        }
        assertTrue(db.getBalance(sortCode, accountNumber).getBalance() == balance);
    }
}
