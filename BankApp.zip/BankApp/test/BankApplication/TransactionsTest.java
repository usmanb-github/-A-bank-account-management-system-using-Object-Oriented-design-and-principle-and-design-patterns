/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BankApplication;

import Hibernate.Hibernate;
import Model.Transactions;
import java.text.SimpleDateFormat;
import java.util.Date;
import org.junit.After;
import org.junit.AfterClass;
import static org.junit.Assert.assertTrue;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

/**
 *
 * @author ub2232e
 */
public class TransactionsTest {

    public TransactionsTest() {
    }

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    // @Test
    // public void hello() {}
    @Test
    public void getTransactions() {
        int sortCode = 816012;
        int accountNumber = 56254125;
        double balanceDue = 2.0;
        double balance = 8.0;
        java.sql.Date date1 = new java.sql.Date((new Date()).getTime());
        Hibernate db = new Hibernate();
        SimpleDateFormat formatNowDay = new SimpleDateFormat("dd");
        SimpleDateFormat formatNowMonth = new SimpleDateFormat("MM");
        SimpleDateFormat formatNowYear = new SimpleDateFormat("YYYY");

        String day = formatNowDay.format(date1);
        String month = formatNowMonth.format(date1);
        String year = formatNowYear.format(date1);

        Transactions wTransaction = new Transactions(sortCode, accountNumber, "WITHDRAW", Integer.toString(sortCode), Integer.toString(accountNumber),
                balanceDue, balance, day, month, year);
        db.createTransactions(wTransaction);
        assertTrue(db.getTransactions().getDue() == 2.0);
    }
}
