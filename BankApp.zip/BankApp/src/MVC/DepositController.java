package MVC;

import BA.MasterPayment;
import BA.Model;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 *
 * @author ub2232e
 */
public class DepositController {

    private DepositView theView;
    Model model = Model.firstInstance();

    public DepositController(DepositView theView) {
        this.theView = theView;
        this.theView.addSubmitActionListener(new SubmitListener());
        this.theView.addGoBackActionListener(new GoBackListener());
    }

    class SubmitListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            model.getDeposit(theView.sortCodeBox, theView.accountNumberBox, theView.amountField);
        }
    }

    class GoBackListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            MasterPayment rs = new MasterPayment();
            rs.setVisible(true);
            rs.setLocationRelativeTo(null);
            theView.setVisible(false);
        }
    }
}
