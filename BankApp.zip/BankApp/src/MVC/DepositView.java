package MVC;

import Hibernate.HibernateInterface;
import Model.Account;
import java.awt.event.ActionListener;
import java.util.List;
import javax.swing.*;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 *
 * @author ub2232e
 */
public class DepositView extends JFrame {

    JLabel sortCodeLabel = new JLabel("Sort Code");
    JComboBox sortCodeBox = new JComboBox();
    JLabel accountNumberLabel = new JLabel("Account Number");
    JComboBox accountNumberBox = new JComboBox();
    JLabel amountLabel = new JLabel("Amount");
    JTextField amountField = new JTextField(7);
    JButton submitButton = new JButton("Submit");
    JButton goBackButton = new JButton("<<");
    ApplicationContext context = new ClassPathXmlApplicationContext("Beans.xml");
    HibernateInterface db = context.getBean(HibernateInterface.class);

    public DepositView() {
        JPanel panel = new JPanel();
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setSize(700, 100);
        this.setLocationRelativeTo(null);
        panel.add(sortCodeLabel);
        panel.add(sortCodeBox);
        List<Account> allAccounts = db.retrieveCheckingAccount();
        Account accounts = null;
        for (int i = 0; i < allAccounts.size(); i++) {
            accounts = (Account) allAccounts.get(i);
            sortCodeBox.addItem(accounts.getSortCode().toString());
        }
        panel.add(accountNumberLabel);
        panel.add(accountNumberBox);
        List<Account> allAccount = db.retrieveCheckingAccount();
        Account account = null;
        for (int i = 0; i < allAccount.size(); i++) {
            account = (Account) allAccount.get(i);
            accountNumberBox.addItem(account.getAccountNumber().toString());
        }
        panel.add(amountLabel);
        panel.add(amountField);
        panel.add(submitButton);
        panel.add(goBackButton);
        this.add(panel);
    }
    public String getTextField3() {
        return amountField.getText();
    }

    void addSubmitActionListener(ActionListener listenforButton) {
        submitButton.addActionListener(listenforButton);
    }

    void addGoBackActionListener(ActionListener listenforButton) {
        goBackButton.addActionListener(listenforButton);
    }

}
