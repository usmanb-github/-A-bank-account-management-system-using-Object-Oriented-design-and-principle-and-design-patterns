package Hibernate;

import Model.Account;
import Model.AccountType;
import Model.Customers;
import Model.Transactions;
import java.util.List;

/**
 *
 * @author ub2232e
 */
public interface HibernateInterface {

    public List<Account> retrieveCheckingAccount();

    public List<Integer> getAccountNumber();

    public List<Integer> getSortCode();

    //retrieves all Customers
    public List<Customers> retrieveCustomer();

    public List<Transactions> retrieveTransactions();

    //create Customers
    public void createCustomer(Customers c);

    public void createTransactions(Transactions c);

    public List<Customers> retrieveFromIdCustomer(int idValue);

    public List<Account> retrieveFromIdAccount(int id);

    public List<Account> retrieveAccount();

    //   public void deletebyId(int idValue);
    public void updateBalance(int sortCode, int accountNumber, double balance);

    public Account getAccount();

    public Customers getCustomers();

    public Account getBalance(int sortCode, int accountNumber);

    public void createAccountType(AccountType c);

    public List<AccountType> retrieveAccountType();

    public Transactions getTransactions();

    public AccountType getAccountType();

    public List<Transactions> retrieveTransactionDate();
}
