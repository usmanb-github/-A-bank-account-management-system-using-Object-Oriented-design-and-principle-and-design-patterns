package Hibernate;

import BA.CheckingAccount;
import Model.Account;
import Model.AccountType;
import Model.Customers;
import Model.Transactions;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

/**
 *
 * @author ub2232e
 */
public class Hibernate implements HibernateInterface {

    private SessionFactory sessionFactory;

    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }

    /**
     *
     * @param c
     */
    @Override
    public void createCustomer(Customers c) {
        Session session = this.sessionFactory.openSession();
        Transaction tx = session.beginTransaction();
        session.persist(c);
        tx.commit();
        session.close();
    }

    /**
     *
     * @param c
     */
    @Override
    public void createAccountType(AccountType c) {
        Session session = this.sessionFactory.openSession();
        Transaction tx = session.beginTransaction();
        session.persist(c);
        tx.commit();
        session.close();
    }

    /**
     *
     * @param c
     */
    @Override
    public void createTransactions(Transactions c) {
        Session session = this.sessionFactory.openSession();
        Transaction tx = session.beginTransaction();
        session.persist(c);
        tx.commit();
        session.close();
    }

    /**
     *
     * @param id
     * @return
     */
    @Override
    public List<Customers> retrieveFromIdCustomer(int id) {
        Session session = this.sessionFactory.openSession();
        session.beginTransaction();
        List<Customers> customersList = session.createQuery("from Customers where id=:id").setInteger("id", id).list();
        session.close();
        return customersList;
    }

    /**
     *
     * @param id
     * @return
     */
    @Override
    public List<Account> retrieveFromIdAccount(int id) {
        Session session = this.sessionFactory.openSession();
        session.beginTransaction();
        List<Account> customersList = session.createQuery("from Account where id=:id").setInteger("id", id).list();
        session.close();
        return customersList;
    }

    /**
     *
     * @return
     */
    @Override
    public List<Customers> retrieveCustomer() {
        Session session = this.sessionFactory.openSession();
        session.beginTransaction();
        List<Customers> customersList = session.createQuery("from Customers").list();
        session.close();
        return customersList;
    }

    @Override
    public List<Transactions> retrieveTransactions() {
        Session session = this.sessionFactory.openSession();
        session.beginTransaction();
        List<Transactions> customersList = session.createQuery("from Transactions").list();
        session.close();
        return customersList;
    }

    @Override
    public List<AccountType> retrieveAccountType() {
        Session session = this.sessionFactory.openSession();
        session.beginTransaction();
        List<AccountType> accountTypeList = session.createQuery("from AccountType").list();
        return accountTypeList;
    }

    /**
     *
     * @return
     */
    @Override
    public List<Account> retrieveAccount() {
        Session session = this.sessionFactory.openSession();
        session.beginTransaction();
        List<Account> customersList = session.createQuery("from Account").list();
        return customersList;
    }

    @Override
    public List<Account> retrieveCheckingAccount() {
        Session session = this.sessionFactory.openSession();
        session.beginTransaction();
        CheckingAccount cr = new CheckingAccount(0.0);
        List<Account> customersList = session.createQuery("from Account Where BankAccountType=:type").setString("type", cr.getClass().getName()).list();
        return customersList;
    }

    @Override
    public List<Transactions> retrieveTransactionDate() {
        Session session = this.sessionFactory.openSession();
        session.beginTransaction();
        java.sql.Date currentDate = new java.sql.Date((new java.util.Date()).getTime());
        SimpleDateFormat formatNowMonth = new SimpleDateFormat("MM");
        String month = formatNowMonth.format(currentDate);
        List<Transactions> customersList = session.createQuery("from Transactions where dateMonth =:date").setString("date", month).list();
        return customersList;
    }

    /**
     *
     * @return
     */
    @Override
    public Account getAccount() {
        Session session = this.sessionFactory.openSession();
        session.beginTransaction();
        Account accounts = null;
        List<Account> allAccounts = retrieveAccount();
        for (int i = 0; i < allAccounts.size(); i++) {
            accounts = (Account) allAccounts.get(i);
        }
        return accounts;
    }

    @Override
    public List<Integer> getSortCode() {
        Session session = this.sessionFactory.openSession();
        session.beginTransaction();
        Account accounts = null;
        List<Account> allAccounts = retrieveAccount();
        List<Integer> sc = new ArrayList<>();

        for (int i = 0; i < allAccounts.size(); i++) {
            accounts = (Account) allAccounts.get(i);
            sc.add(accounts.getSortCode());
        }
        return sc;
    }

    @Override
    public List<Integer> getAccountNumber() {
        Session session = this.sessionFactory.openSession();
        session.beginTransaction();
        Account accounts = null;
        List<Account> allAccounts = retrieveAccount();
        List<Integer> sc = new ArrayList<>();

        for (int i = 0; i < allAccounts.size(); i++) {
            accounts = (Account) allAccounts.get(i);
            sc.add(accounts.getAccountNumber());
        }
        return sc;
    }

    @Override
    public Transactions getTransactions() {
        Session session = this.sessionFactory.openSession();
        session.beginTransaction();
        Transactions transaction = null;
        List<Transactions> allTransactions = retrieveTransactions();
        for (int i = 0; i < allTransactions.size(); i++) {
            transaction = (Transactions) allTransactions.get(i);
        }
        return transaction;
    }

    @Override
    public Customers getCustomers() {
        Session session = this.sessionFactory.openSession();
        session.beginTransaction();
        Customers customer = null;
        List<Customers> allCustomers = retrieveCustomer();
        for (int i = 0; i < allCustomers.size(); i++) {
            customer = (Customers) allCustomers.get(i);
            System.out.println(customer.getFirstname()); //retrieves them as a list. you can get them all here.
        }
        return customer;
    }

    /**
     *
     * @param sortCode
     * @param accountNumber
     * @return
     */
    @Override
    public Account getBalance(int sortCode, int accountNumber) {
        Session session = this.sessionFactory.openSession();
        session.beginTransaction();
        Query queryResult = session.createQuery("from Account WHERE sortCode = :sortCode AND accountNumber = :accountNumber");
        queryResult.setInteger("sortCode", sortCode);
        queryResult.setInteger("accountNumber", accountNumber);

        List<Account> allAccounts;
        allAccounts = queryResult.list();
        session.getTransaction().commit();

        Account accounts;
        for (int i = 0; i < allAccounts.size(); i++) {
            accounts = (Account) allAccounts.get(i);
            return accounts;
        }
        return null;
    }

    /**
     *
     * @param sortCode
     * @param accountNumber
     * @param balance
     */
    @Override
    public void updateBalance(int sortCode, int accountNumber, double balance) {
        Session session = this.sessionFactory.openSession();

        session.beginTransaction();
        String queryString = "UPDATE from Account SET balance = :balance where sortCode = :sortCode AND  accountNumber = :accountNumber";
        //UPDATE entity SET attribute='value' WHERE anotherAttribute IN (val1, val2);
        Query query = session.createQuery(queryString);
        query.setInteger("sortCode", sortCode);
        query.setInteger("accountNumber", accountNumber);
        query.setDouble("balance", balance);
        query.executeUpdate();
        session.getTransaction().commit();
    }

    @Override
    public AccountType getAccountType() {
        Session session = this.sessionFactory.openSession();
        session.beginTransaction();
        List<AccountType> allAccounts = retrieveAccountType();
        AccountType accounts = null;
        for (int i = 0; i < allAccounts.size(); i++) {
            accounts = (AccountType) allAccounts.get(i);
            return accounts;

        }
        return null;
    }
}
