package Model;

import java.io.Serializable;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

/**
 *
 * @author ub2232e
 */
@Entity
public class Customers implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer Id;
    private String firstname;
    private String lastname;
    private String address;
    private String email;
    private Integer phoneNumber;
    private Integer passportID;
    private String bankAccount;
    @ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
    private Account accountLink;

    public Customers() {

    }

    public Customers(String firstname, String lastname, String address, String email, 
            Integer passportID, Integer phoneNumber, String bankAccount, Account accountLink) {
        this.firstname = firstname;
        this.lastname = lastname;
        this.address = address;
        this.email = email;
        this.passportID = passportID;
        this.phoneNumber = phoneNumber;
        this.bankAccount = bankAccount;
        this.accountLink = accountLink;
    }

    public Integer getId() {
        return Id;
    }

    public void setId(Integer Id) {
        this.Id = Id;
    }

    public String getFirstname() {
        return firstname;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public String getLastname() {
        return lastname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Integer getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(Integer phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public Integer getPassportID() {
        return passportID;
    }

    public void setPassportID(Integer passportID) {
        this.passportID = passportID;
    }

    public String getBankAccount() {
        return bankAccount;
    }

    public void setBankAccount(String bankAccount) {
        this.bankAccount = bankAccount;
    }

    public Account getAccountLink() {
        return accountLink;
    }

    public void setAccountLink(Account accountLink) {
        this.accountLink = accountLink;
    }
    
}
