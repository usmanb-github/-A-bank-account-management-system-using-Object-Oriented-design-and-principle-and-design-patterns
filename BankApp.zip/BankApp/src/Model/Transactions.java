package Model;

import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

/**
 *
 * @author ub2232e
 */
@Entity
public class Transactions implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer transactionID;
    private Integer sortCode;
    private Integer accountNumber;
    private String paymentType;
    private String D1;
    private String D2;
    private String D3;
    private String D4;
    private Double due;
    private Double balance;
    private String dateDay;
    private String dateMonth;
    private String dateYear;

    public Transactions() {

    }

    public Transactions(Integer sortCode, Integer accountNumber, String paymentType, String D1, String D2,
            String D3, String D4, Double due, Double balance, String dateDay, String dateMonth, String dayYear) {
        this.sortCode = sortCode;
        this.accountNumber = accountNumber;
        this.paymentType = paymentType;
        this.D1 = D1;
        this.D2 = D2;
        this.D3 = D3;
        this.D4 = D4;
        this.due = due;
        this.balance = balance;
        this.dateDay = dateDay;
        this.dateMonth = dateMonth;
        this.dateYear = dayYear;

    }

    public Transactions(Integer sortCode, Integer accountNumber, String paymentType,
            String D1, String D2, Double due, Double balance, String dateDay, String dateMonth, String dayYear) {
        this.sortCode = sortCode;
        this.accountNumber = accountNumber;
        this.paymentType = paymentType;
        this.D1 = D1;
        this.D2 = D2;
        this.due = due;
        this.balance = balance;
        this.dateDay = dateDay;
        this.dateMonth = dateMonth;
        this.dateYear = dayYear;
    }

    public Integer getTransactionID() {
        return transactionID;
    }

    public void setTransactionID(Integer transactionID) {
        this.transactionID = transactionID;
    }

    public Integer getSortCode() {
        return sortCode;
    }

    public void setSortCode(Integer sortCode) {
        this.sortCode = sortCode;
    }

    public Integer getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(Integer accountNumber) {
        this.accountNumber = accountNumber;
    }

    public String getPaymentType() {
        return paymentType;
    }

    public void setPaymentType(String paymentType) {
        this.paymentType = paymentType;
    }

    public String getD1() {
        return D1;
    }

    public void setD1(String D1) {
        this.D1 = D1;
    }

    public String getD2() {
        return D2;
    }

    public void setD2(String D2) {
        this.D2 = D2;
    }

    public String getD3() {
        return D3;
    }

    public void setD3(String D3) {
        this.D3 = D3;
    }

    public String getD4() {
        return D4;
    }

    public void setD4(String D4) {
        this.D4 = D4;
    }

    public Double getDue() {
        return due;
    }

    public void setDue(Double due) {
        this.due = due;
    }

    public Double getBalance() {
        return balance;
    }

    public void setBalance(Double balance) {
        this.balance = balance;
    }

    public String getDateDay() {
        return dateDay;
    }

    public void setDateDay(String dateDay) {
        this.dateDay = dateDay;
    }

    public String getDateMonth() {
        return dateMonth;
    }

    public void setDateMonth(String dateMonth) {
        this.dateMonth = dateMonth;
    }

    public String getDateYear() {
        return dateYear;
    }

    public void setDateYear(String dateYear) {
        this.dateYear = dateYear;
    }

    

}
