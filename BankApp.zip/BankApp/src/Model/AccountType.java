package Model;

import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

/**
 *
 * @author ub2232e
 */
@Entity
public class AccountType implements Serializable {
    
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int accountID;
    private String account;

    public AccountType() {
    }

    public AccountType(String account) {
        this.account = account;
    }
    
    public String getAccount() {
        return account;
    }

    public void setAccount(String account) {
        this.account = account;
    }
    
}
