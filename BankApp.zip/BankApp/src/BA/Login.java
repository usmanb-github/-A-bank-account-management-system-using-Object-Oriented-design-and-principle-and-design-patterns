package BA;

import javax.swing.JTextField;
/**
 *
 * @author ub2232e
 */
public class Login {

    private JTextField username;
    private JTextField password;

    public Login(JTextField user, JTextField pass) {
        this.username = user;
        this.password = pass;
    }

    public void validation() {
        Model model = new Model();
        if (username.getText().matches("ha07") && password.getText().matches("ha07")) {
            model.displayMessage("Welcome.");
            Master ms = new Master();
            ms.setVisible(true);
            ms.setLocationRelativeTo(null);
        } else {
            model.displayMessage("Incorrect details. Please try again.");
        }
    }

    public JTextField getUsername() {
        return username;
    }

    public void setUsername(JTextField username) {
        this.username = username;
    }

    public JTextField getPassword() {
        return password;
    }

    public void setPassword(JTextField password) {
        this.password = password;
    }
}
