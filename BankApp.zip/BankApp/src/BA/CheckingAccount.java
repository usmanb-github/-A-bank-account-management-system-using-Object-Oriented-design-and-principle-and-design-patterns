package BA;

/**
 *
 * @author ub2232e
 */
public class CheckingAccount extends BankAccount {

    private static final int freeTransaction = 5;
    private static final double transactionFee = 1.0;
    private int transactionCount;

   public CheckingAccount(double amount) {
        super(amount);
    }

    @Override
    public void deposit(double amount) {
        super.deposit(amount); 
        transactionCount++;
    }

    @Override
    public void withdraw(double amount) {
        super.withdraw(amount);
        transactionCount++;
    }

    public void deductFees() {
        if (transactionCount > freeTransaction) {
            double fees = transactionFee * (transactionCount - freeTransaction);
            super.withdraw(fees);
        }
        transactionCount = 0;
    }
}
