package BA;

/**
 *
 * @author ub2232e
 */
public class ISAAccount extends BankAccount {

    ISAAccount(double amount) {
        super(amount);
    }
}
