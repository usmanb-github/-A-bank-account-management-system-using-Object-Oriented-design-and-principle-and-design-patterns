package BA;

/**
 *
 * @author ub2232e
 */
public class BankAccount {
    private double balance;
    
    BankAccount(double amount) {
        balance = amount;
    }
    
    protected  double getBalance() {
        return balance;
    }
    
    protected void withdraw(double amount) {
        if(balance >= amount)
            balance -= amount;
    }
    
    protected void deposit(double amount) {
        balance += amount;
    }
    protected void transfer(double amount, BankAccount bank) {
        this.withdraw(amount);
        bank.deposit(amount);
    }
}

