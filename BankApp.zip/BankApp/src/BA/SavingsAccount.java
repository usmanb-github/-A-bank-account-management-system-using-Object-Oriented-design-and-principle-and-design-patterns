package BA;

/**
 *
 * @author ub2232e
 */
public class SavingsAccount extends BankAccount {

    private final double interestRate;

    // constructor
    SavingsAccount(double amount, double rate) {
        super(amount);
        interestRate = rate;
    }

    public void addInterest() {
        double interest = getBalance() * interestRate / 100;
        super.deposit(interest); // calling super class's deposit method
    }
}
