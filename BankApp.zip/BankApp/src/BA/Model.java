package BA;

import Hibernate.HibernateInterface;
import Model.Account;
import Model.Customers;
import Model.Transactions;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Random;
import java.util.regex.Pattern;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 *
 * @author ub2232e
 */
public class Model {

    ApplicationContext context = new ClassPathXmlApplicationContext("Beans.xml");
    HibernateInterface db = context.getBean(HibernateInterface.class);
    private static Model firstInstance;
    private static double balance = 0;
    private static final double interestRate = 0.2;
    private static BankAccount cr = new CheckingAccount(balance);
    private static BankAccount sa = new SavingsAccount(balance, interestRate);
    private static BankAccount isa = new ISAAccount(balance);

    public static Model firstInstance() {
        if (firstInstance == null) {
            firstInstance = new Model();
        }
        return firstInstance;
    }

    /**
     *
     * @param message
     * @param string
     * @param a
     */
    public void displayErrorMessage(String message, String string) {
        int ea = JOptionPane.ERROR_MESSAGE;
        JOptionPane.showMessageDialog(null, message, string, ea);
        //uses method to shorten code
    }

    /**
     *
     * @param string
     */
    public void displayMessage(String string) {
        JOptionPane.showMessageDialog(null, string);
        //uses method to shorten code
    }

    /**
     *
     * @param email
     * @return
     */
    public boolean isValid(String email) {
        String emailRegex = "^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"
                + "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";

        Pattern pattern = Pattern.compile(emailRegex);
        if (email == null) {
            return false;
        }
        return pattern.matcher(email).matches();
    }

    /**
     *
     * @param field
     * @return
     */
    public boolean isWord(String field) {
        return Pattern.matches("^[ a-zA-z]+$", field);
    }

    /**
     *
     * @param field
     * @return
     */
    public boolean isNumber(String field) {
        return Pattern.matches("^[ 0-9]+", field);
    }

    /**
     *
     * @param field
     * @return
     */
    public boolean isDoubleNumber(String field) {
        if (true) {
            return Pattern.matches("^[0-9]{1,13}+(\\.[0-9]{1,2})?$", field);
        } else {
            return false;
        }
    }

    /**
     *
     * @param field
     * @return
     */
    public boolean isNumberAndWord(String field) {
        return Pattern.matches("^[ a-zA-Z0-9]+", field);
    }

    /**
     *
     * @return day
     */
    public String getDay() {
        java.sql.Date date1 = new java.sql.Date((new Date()).getTime());
        SimpleDateFormat formatNowDay = new SimpleDateFormat("dd");
        String day = formatNowDay.format(date1);
        return day;
    }

    /**
     *
     * @return month
     */
    public String getMonth() {
        java.sql.Date date1 = new java.sql.Date((new Date()).getTime());
        SimpleDateFormat formatNowMonth = new SimpleDateFormat("MM");
        String month = formatNowMonth.format(date1);
        return month;
    }

    /**
     *
     * @return year
     */
    public String getYear() {
        java.sql.Date date1 = new java.sql.Date((new Date()).getTime());
        SimpleDateFormat formatNowYear = new SimpleDateFormat("YYYY");
        String year = formatNowYear.format(date1);
        return year;
    }

    public void getCreditCard(JComboBox sortCodeBox, JComboBox accountNumberBox, JTextField nameField, JTextField digitCardField,
            JTextField CVVField, JTextField expiryField, JTextField amountField) {
        int resultSortCode = Integer.parseInt(sortCodeBox.getSelectedItem().toString());
        int resultAccountNumber = Integer.parseInt(accountNumberBox.getSelectedItem().toString());
        double resultInput = Double.parseDouble(amountField.getText());
        if (db.getSortCode().contains(resultSortCode) && db.getAccountNumber().contains(resultAccountNumber)) {

            double result = (db.getBalance(resultSortCode, resultAccountNumber).getBalance() - resultInput);
            db.updateBalance(resultSortCode, resultAccountNumber, result);
            System.out.println(amountField.getText() + " " + "using Credit Card");

            Transactions nPT = new Transactions(resultSortCode, resultAccountNumber,
                    "CREDIT CARD", nameField.getText(), digitCardField.getText(), CVVField.getText(),
                    expiryField.getText(), resultInput, result, getDay(), getMonth(), getYear());
            db.createTransactions(nPT);
        }
    }

    public void getDirectTransfer(JComboBox sortCodeBox, JComboBox accountNumberBox, JTextField sortCodeField, JTextField accountNumberField, JTextField amountField) {
        String sortCode = sortCodeBox.getSelectedItem().toString();
        String accountNumber = accountNumberBox.getSelectedItem().toString();
        String sortCode2 = sortCodeField.getText();
        String accountNumber2 = accountNumberField.getText();
        String amountDue = amountField.getText();

        if (sortCode.isEmpty() && accountNumber.isEmpty()
                && sortCode2.isEmpty() && accountNumber2.isEmpty() && amountDue.isEmpty()) {
            displayMessage("Please fill in the rest of the details to submit a payment");
        } else if (!(isNumber(sortCode) && isNumber(accountNumber)
                && isNumber(sortCode2) && isNumber(accountNumber2))) {
            displayMessage("Please enter a valid number");
        } else if (!(isDoubleNumber(amountDue))) {
            displayMessage("This is not correct format.");
        } else {
            int resultSortCode = Integer.parseInt(sortCode);
            int resultAccountNumber = Integer.parseInt(accountNumber);
            double resultInput = Double.parseDouble(amountDue);
            if (db.getSortCode().contains(resultSortCode) && db.getAccountNumber().contains(resultAccountNumber)) {
                double result = (db.getBalance(resultSortCode, resultAccountNumber).getBalance() - resultInput);
                db.updateBalance(resultSortCode, resultAccountNumber, result);
                System.out.println(amountField.getText() + " " + "using Direct Transfer");

                Transactions nPT = new Transactions(resultSortCode, resultAccountNumber, "DIRECT TRANSFER", sortCode2, accountNumber2,
                        resultInput, result, getDay(), getMonth(), getYear());
                db.createTransactions(nPT);
            }
        }
    }

    public void getPayPal(JComboBox sortCodeBox, JComboBox accountNumberBox, JTextField usernameField, JPasswordField passwordField, JTextField amountField) {
        String sortCode = sortCodeBox.getSelectedItem().toString();
        String accountNumber = accountNumberBox.getSelectedItem().toString();
        String username = usernameField.getText();
        String password = passwordField.getText();
        String amount = amountField.getText();

        if (sortCode.isEmpty() && accountNumber.isEmpty()
                && username.isEmpty() && password.isEmpty() && amount.isEmpty()) {
            displayMessage("Please fill in the rest of the details to submit a payment");
        } else if (!isValid(username)) {
            displayMessage("Please enter a valid email address");
        } else if (!(isNumber(sortCode) && isNumber(accountNumber))) {
            displayMessage("Please enter a valid number");
        } else if (!(isDoubleNumber(amount))) {
            displayMessage("This is not correct format.");
        } else {
            int resultSortCode = Integer.parseInt(sortCode);
            int resultAccountNumber = Integer.parseInt(accountNumber);
            double resultInput = Double.parseDouble(amount);
            if (db.getSortCode().contains(resultSortCode) && db.getAccountNumber().contains(resultAccountNumber)) {
                double result = (db.getBalance(resultSortCode, resultAccountNumber).getBalance() - resultInput);
                db.updateBalance(resultSortCode, resultAccountNumber, result);

                System.out.println(amountField.getText() + " " + "using PayPal");

                Transactions nPT = new Transactions(resultSortCode, resultAccountNumber, "PAYPAL", username,
                        password, Double.parseDouble(amountField.getText()), result, getDay(), getMonth(), getYear());
                db.createTransactions(nPT);
                System.out.println("Transaction has been complete");
            }
        }
    }

    public void getTransfer(JComboBox toSortCodeBox, JComboBox toAccountNumberBox, JComboBox fromSortCodeBox, JComboBox fromAccountNumberBox, JTextField amountField) {
        String sortCode = toSortCodeBox.getSelectedItem().toString();
        String accountNumber = toAccountNumberBox.getSelectedItem().toString();
        String sortCode2 = fromSortCodeBox.getSelectedItem().toString();
        String accountNumber2 = fromAccountNumberBox.getSelectedItem().toString();
        String amountDue = amountField.getText();

        if (sortCode.isEmpty() && accountNumber.isEmpty()
                && sortCode2.isEmpty() && accountNumber2.isEmpty() && amountDue.isEmpty()) {
            displayMessage("Please fill in the rest of the details to submit a payment");
        } else if (!(isNumber(sortCode) && isNumber(accountNumber)
                && isNumber(sortCode2) && isNumber(accountNumber2))) {
            displayMessage("Please enter a valid number");
        } else if (!(isDoubleNumber(amountDue))) {
            displayMessage("This is not correct format.");
        } else {
            int fromSortCode = Integer.parseInt(sortCode);
            int fromAccountNumber = Integer.parseInt(accountNumber);
            int toSortCode = Integer.parseInt(sortCode2);
            int toAccountNumber = Integer.parseInt(accountNumber2);
            double amount = Double.parseDouble(amountDue);

            if (db.getSortCode().contains(fromSortCode) && db.getAccountNumber().contains(fromAccountNumber)
                    && db.getSortCode().contains(toSortCode) && db.getAccountNumber().contains(toAccountNumber)) {
                {
                    double resultTo = (db.getBalance(toSortCode, toAccountNumber).getBalance() + amount);
                    db.updateBalance(toSortCode, toAccountNumber, resultTo);

                    double resultFrom = (db.getBalance(fromSortCode, fromAccountNumber).getBalance() - amount);
                    db.updateBalance(fromSortCode, fromAccountNumber, resultFrom);
                    System.out.println(amountField.getText() + " " + " Transfer Accounts");

                    Transactions nPT = new Transactions(fromSortCode, fromAccountNumber, "TRANSFER",
                            sortCode2, accountNumber2, amount, resultTo, getDay(), getMonth(), getYear());
                    db.createTransactions(nPT);

                    System.out.println(amountField.getText() + " " + " Transfer Accounts");
                    Transactions nPT1 = new Transactions(toSortCode, toAccountNumber, "TRANSFER",
                            sortCode, accountNumber, amount, resultFrom, getDay(), getMonth(), getYear());
                    db.createTransactions(nPT1);
                }
            }
        }
    }

    public void getWithdraw(JComboBox sortCodeBox, JComboBox accountNumberBox, JTextField amountField) {
        String sortCodeString = sortCodeBox.getSelectedItem().toString();
        String accountNumberString = accountNumberBox.getSelectedItem().toString();
        String amountString = amountField.getText();

        if (sortCodeString.isEmpty() && accountNumberString.isEmpty() && amountString.isEmpty()) {
            displayMessage("Please fill in the rest of the details to submit a payment");
        } else if (!(isDoubleNumber(amountString) && isNumber(sortCodeString) && isNumber(accountNumberString))) {
            displayMessage("This is not correct format.");
        } else {
            int sortCodeInt = Integer.parseInt(sortCodeString);
            int accountNumberInt = Integer.parseInt(accountNumberString);
            double amountDouble = Double.parseDouble(amountString);

            if (db.getSortCode().contains(sortCodeInt) && db.getAccountNumber().contains(accountNumberInt)) {
                double result = (db.getBalance(sortCodeInt, accountNumberInt).getBalance() - amountDouble);
                System.out.println("BEFORE BALANCE:" + db.getBalance(sortCodeInt, accountNumberInt).getBalance());
                db.updateBalance(sortCodeInt, accountNumberInt, result);
                System.out.println("AFTER BALANCE:" + db.getBalance(sortCodeInt, accountNumberInt).getBalance());
                System.out.println(amountField.getText() + " " + " Withdraw");

                Transactions wTransaction = new Transactions(sortCodeInt, accountNumberInt, "WITHDRAW",
                        sortCodeString, accountNumberString, amountDouble, result, getDay(), getMonth(), getYear());
                db.createTransactions(wTransaction);
            }
        }
    }

    public void getDeposit(JComboBox sortCodeBox, JComboBox accountNumberBox, JTextField amountField) {
        String sortCodeString = sortCodeBox.getSelectedItem().toString();
        String accountNumberString = accountNumberBox.getSelectedItem().toString();
        String amountString = amountField.getText();

        if (sortCodeString.isEmpty() && accountNumberString.isEmpty() && amountString.isEmpty()) {
            displayMessage("Please fill in the rest of the details to submit a payment");
        } else if (!(isDoubleNumber(amountString) && isNumber(sortCodeString) && isNumber(accountNumberString))) {
            displayMessage("This is not correct format.");
        } else {
            int sortCodeInt = Integer.parseInt(sortCodeString);
            int accountNumberInt = Integer.parseInt(accountNumberString);
            double amountDouble = Double.parseDouble(amountString);

            if (db.getSortCode().contains(sortCodeInt) && db.getAccountNumber().contains(accountNumberInt)) {
                double result = (db.getBalance(sortCodeInt, accountNumberInt).getBalance() + amountDouble);
                System.out.println("BEFORE BALANCE:" + db.getBalance(sortCodeInt, accountNumberInt).getBalance());
                db.updateBalance(sortCodeInt, accountNumberInt, result);
                System.out.println("AFTER BALANCE:" + db.getBalance(sortCodeInt, accountNumberInt).getBalance());
                System.out.println(amountField.getText() + " " + " Deposit");

                Transactions wTransaction = new Transactions(sortCodeInt, accountNumberInt, "DEPOSIT",
                        sortCodeString, accountNumberString, amountDouble, result, getDay(), getMonth(), getYear());
                db.createTransactions(wTransaction);
            }
        }
    }

    public void getCustomer(JTextField nameField, JTextField surnameField, JTextField passportField, JTextField phoneField,
            JTextField addressField, JTextField emailField, JComboBox accountTypeField) {
        String name = nameField.getText();
        String surname = surnameField.getText();
        int passportID = Integer.parseInt(passportField.getText());
        int phoneNumber = Integer.parseInt(phoneField.getText());
        String address = addressField.getText();
        String email = emailField.getText();
        if (name.isEmpty() && surname.isEmpty() && passportField.getText().isEmpty()
                && phoneField.getText().isEmpty() && address.isEmpty()
                && email.isEmpty()) {
            displayMessage("Please fill in the rest of this to complete");
        } else if (!isValid(emailField.getText())) {
            displayMessage("Please enter a valid email address");
        } else if (!(isNumber(passportField.getText()) && isNumber(phoneField.getText()))) {
            displayMessage("Please enter a valid number");
        } else {
            if ("Checking Account".equals(accountTypeField.getSelectedItem().toString())) {
                cr = new CheckingAccount(balance);
                Account account = new Account(Integer.parseInt(getSortCode()), Integer.parseInt(getAccountNumber()), "Greenwich", "GW015", cr.getClass().getName().toString(), balance);
                Customers newCustomers = new Customers(name, surname, address, email, phoneNumber, passportID, cr.getClass().getName().toString(), account);
                db.createCustomer(newCustomers);
            } else if ("Saving Account".equals(accountTypeField.getSelectedItem().toString())) {
                sa = new SavingsAccount(balance, 0.2);
                Account account = new Account(Integer.parseInt(getSortCode()), Integer.parseInt(getAccountNumber()), "Greenwich", "GW015", sa.getClass().getName().toString(), balance);
                Customers newCustomers = new Customers(name, surname, address, email, phoneNumber, passportID, sa.getClass().getName().toString(), account);
                db.createCustomer(newCustomers);
            } else if ("ISA".equals(accountTypeField.getSelectedItem().toString())) {
                isa = new ISAAccount(balance);
                Account account = new Account(Integer.parseInt(getSortCode()), Integer.parseInt(getAccountNumber()), "Greenwich", "GW015", isa.getClass().getName().toString(), balance);
                Customers newCustomers = new Customers(name, surname, address, email, phoneNumber, passportID, isa.getClass().getName().toString(), account);
                db.createCustomer(newCustomers);
            }
        }
    }

    public static String getSortCode() {
        Random randomSortCode = new Random();
        int resultSortCode = 0;
        int lowSortCode = 10;
        int highSortCode = 100;
        ArrayList finalOutput = new ArrayList();
        for (int i = 0; i < 3; i++) {
            resultSortCode = randomSortCode.nextInt(highSortCode - lowSortCode) + lowSortCode;
            finalOutput.add(resultSortCode);
        }
        int getFirstS = (int) finalOutput.get(0);
        int getSecondS = (int) finalOutput.get(1);
        int getThirdS = (int) finalOutput.get(2);
        return Integer.toString(getFirstS) + Integer.toString(getSecondS) + Integer.toString(getThirdS);
    }

    public static String getAccountNumber() {
        Random r = new Random();
        int Result = 0;
        int low = 10;
        int high = 100;
        ArrayList finalOutput1 = new ArrayList();
        for (int i = 0; i < 4; i++) {
            Result = r.nextInt(high - low) + low;
            finalOutput1.add(Result);
        }
        int getFirst = (int) finalOutput1.get(0);
        int getSecond = (int) finalOutput1.get(1);
        int getThird = (int) finalOutput1.get(2);
        int getForth = (int) finalOutput1.get(3);
        return Integer.toString(getFirst) + Integer.toString(getSecond) + Integer.toString(getThird) + Integer.toString(getForth);
    }

    public static Double getBalance() {
        return balance;
    }

   public void getStandingOrder(JComboBox sortCodeBox, JComboBox accountNumberBox, JTextField numberField, JPasswordField CVVField, 
            JTextField amountField) {
        String sortCode = sortCodeBox.getSelectedItem().toString();
        String accountNumber = accountNumberBox.getSelectedItem().toString();
        String number = numberField.getText();
        String CVV = CVVField.getText();
        String amount = amountField.getText();

        if (sortCode.isEmpty() && accountNumber.isEmpty()
                && number.isEmpty() && CVV.isEmpty() && amount.isEmpty()) {
            displayMessage("Please fill in the rest of the details to submit a payment");
        } else if (!(isNumber(sortCode) && isNumber(accountNumber))) {
            displayMessage("Please enter a valid number");
        } else if (!(isDoubleNumber(amount))) {
            displayMessage("This is not correct format.");
        } else {
            int resultSortCode = Integer.parseInt(sortCode);
            int resultAccountNumber = Integer.parseInt(accountNumber);
            double resultInput = Double.parseDouble(amount);
            if (db.getSortCode().contains(resultSortCode) && db.getAccountNumber().contains(resultAccountNumber)) {
                double result = (db.getBalance(resultSortCode, resultAccountNumber).getBalance() - resultInput);
                db.updateBalance(resultSortCode, resultAccountNumber, result);

                System.out.println(amount + " " + "using Standing Order");

                Transactions nPT = new Transactions(resultSortCode, resultAccountNumber, "STANDING ORDER", number,
                        CVV, Double.parseDouble(amountField.getText()), result, getDay(), getMonth(), getYear());
                db.createTransactions(nPT);
                System.out.println("Transaction has been complete");
            }
        }
    }
}
