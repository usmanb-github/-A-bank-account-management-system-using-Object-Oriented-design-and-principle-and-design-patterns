README.txt

To run the application:
Go to Services,
Right Click Java DB and click on Properties,
Direct Database Location to the selected Task you wish to open,
Right Click on Database and enter the details to connect to the database,
Enter the details below:
username:ha07
password:ha07

ADD IF THE APPLICATION DOES NOT RUN AFTER DATABASE CONNECTION
If this does not work, 
please select the Java DB Driver library,
Hibernate4.3x(JPA.21),
and Spring Framework 4.0.1
and add it to the library.

If not, please email me on ub2232e@greenwich.ac.uk
